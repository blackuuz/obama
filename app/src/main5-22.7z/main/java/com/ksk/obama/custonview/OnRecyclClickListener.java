package com.ksk.obama.custonview;

/**
 * Created by djy on 2017/2/22.
 */

public interface OnRecyclClickListener {
    void OnClickRecyclListener(int position);
}
