package com.ksk.obama.printer;

import java.util.Map;

/**
 * Created by xinle on 1/14/17.
 */

public class CardInfo {


    public int cardType;

    public int cardStatus;

    public String PAN;

    public String track2;

    public Map hashMap;


}
