package com.ksk.obama.callback;

/**
 * Created by Administrator on 2016/9/19.
 */
public interface IReadCardId {
    void readCardNo(String cardNo,String UID);
}
