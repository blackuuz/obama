package com.ksk.obama.callback;

/**
 * Created by Administrator on 2016/11/9.
 */

public interface IQrcodeCallBack {
    void OnReadQrcode(String number);
}
