package com.ksk.obama.callback;

/**
 * Created by Administrator on 2016/11/3.
 */

public interface IConnectCallBack {
    void onConnected();
}
