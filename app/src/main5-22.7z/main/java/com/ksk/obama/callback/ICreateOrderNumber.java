package com.ksk.obama.callback;

/**
 * Created by djy on 2017/2/6.
 */

public interface ICreateOrderNumber {

    void OnCreateOrderNumber(boolean isFail);
}
