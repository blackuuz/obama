package com.ksk.obama.callback;

/**
 * Created by djy on 2017/1/5.
 */

public interface IPrintErrorCallback {
    void OnPrintError();
}
