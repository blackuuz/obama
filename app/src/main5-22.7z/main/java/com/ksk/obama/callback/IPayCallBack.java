package com.ksk.obama.callback;

/**
 * Created by Administrator on 2016/9/23.
 */

public interface IPayCallBack {
    void OnPaySucess(String orderNum,int payMode);
}
